test('This is my first test case', () => {
    1 + 2
})

test('My second test ever!', () => {

})