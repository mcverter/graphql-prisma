const Comment = {

}

export { Comment as default }