const Post = {

}

export { Post as default }