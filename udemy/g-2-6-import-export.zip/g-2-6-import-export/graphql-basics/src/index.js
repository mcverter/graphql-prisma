import myAddFunction, { subtract } from './math'

console.log(myAddFunction(1, -2))
console.log(subtract(10, 2))