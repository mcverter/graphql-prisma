const add = (a, b) => a + b

const subtract = (a, b) => a - b

export { add as default, subtract }